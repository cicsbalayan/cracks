Gingerbread Resource Pack, Copywright 2009 

................***************************...................

Suzanne Powell suztv@suztv.com

................***************************...................



................***************************...................

System Requirements:

Photoshop Styles, brushes and shapes:
Photoshop Version CS2 or above - PC or Macintosh

Tiling Textures and images:
Any Image editing program that can open PNG files


................***************************...................

To install:

Copy to your harddrive...

Brushes:

Open up your preset manager by clicking on "Edit" in the main menu then select "preset manager"
from there select "Brushes" from the drop-down menu at the top.  Then click on "load" - select the gingerbread brushes in the folder that you placed it in.


All items and content in this package were created by Suzanne Powell.